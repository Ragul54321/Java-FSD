package lesson4;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
      
        Queue<String> locationsQueue = new LinkedList<>();

        locationsQueue.add("Kolkata");
        locationsQueue.add("Patna");
        locationsQueue.add("Delhi");
        locationsQueue.add("Gurgaon");
        locationsQueue.add("Noida");

       
        System.out.println("Queue: " + locationsQueue);

       
        System.out.println("Head of Queue: " + locationsQueue.peek());

      
        locationsQueue.poll();

        
        System.out.println("Queue after removing head: " + locationsQueue);

     
        System.out.println("Size of Queue: " + locationsQueue.size());
    }
}
