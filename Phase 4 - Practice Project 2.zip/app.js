// Initialize an array to store team budgets
let teamBudgets = [];

// Function to add team budget
function addTeamBudget() {
  // Get values from form inputs
  let teamName = document.getElementById('teamName').value;
  let teamExpenses = parseFloat(document.getElementById('teamExpenses').value);

  // Validate input
  if (!teamName || isNaN(teamExpenses)) {
    alert('Please enter valid values for Team Name and Team Expenses.');
    return;
  }

  // Add team budget to the array
  teamBudgets.push({
    teamName: teamName,
    teamExpenses: teamExpenses
  });

  // Update the display of team budgets
  displayTeamBudgets();
}

// Function to calculate total budget
function calculateTotalBudget() {
  // Calculate the total budget
  let totalBudget = teamBudgets.reduce((sum, budget) => sum + budget.teamExpenses, 0);

  // Display the total budget
  document.getElementById('totalBudget').innerHTML = 'Total Budget: $' + totalBudget.toFixed(2);
}

// Function to display team budgets
function displayTeamBudgets() {
  // Get the element to display team budgets
  let teamBudgetsElement = document.getElementById('teamBudgets');

  // Clear the previous content
  teamBudgetsElement.innerHTML = '';

  // Display each team budget
  teamBudgets.forEach((budget, index) => {
    teamBudgetsElement.innerHTML += `Team ${index + 1}: ${budget.teamName} - Expenses: $${budget.teamExpenses.toFixed(2)}<br>`;
  });
}
