package com.example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String productName = request.getParameter("productName");
        double price = Double.parseDouble(request.getParameter("price"));

        // Create a Product object
        Product product = new Product();
        product.setProductName(productName);
        product.setPrice(price);

        // Store the product in the session
        HttpSession sessionObj = request.getSession();
        sessionObj.setAttribute("product", product);

        // Redirect to the second JSP page
        response.sendRedirect("displayProduct.jsp");
    }
}
